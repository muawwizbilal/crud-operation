import * as firebase from "firebase";
const firebaseConfig = {
  apiKey: "AIzaSyCOMa7wWTAY9QMmX_lgWQQL2BQ7jQfuYfs",
  authDomain: "react-js-crudoperation.firebaseapp.com",
  databaseURL: "https://react-js-crudoperation-default-rtdb.firebaseio.com",
  projectId: "react-js-crudoperation",
  storageBucket: "react-js-crudoperation.appspot.com",
  messagingSenderId: "333773166340",
  appId: "1:333773166340:web:13fb51ea50c76d597a2251"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);